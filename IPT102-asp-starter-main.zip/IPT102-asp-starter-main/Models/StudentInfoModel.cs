public class StudentInfoModel
{
    public string Name { get; set; }
    public string StudentId { get; set; }
    public string StudentAge { get; set; }
}
